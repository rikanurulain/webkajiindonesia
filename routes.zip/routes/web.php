<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\HalalCenterController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\KonsultanController;
use App\Http\Controllers\MediaController;
use App\Http\Controllers\PelatihanController;
use App\Http\Controllers\UmkmController;
use Illuminate\Support\Facades\Route;
// use App\Http\Controllers\ProfilController;
// use App\Http\Controllers\ActivityController;
use App\Http\Controllers\AdminController;

// Beranda
Route::get('/', [HomeController::class , 'index'])->name('home');

// =====================
// AUTH
// =====================
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register']);

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);

// === LOGOUT ROUTE
Route::post('/logout', [AuthController::class, 'logout'])
     ->middleware('auth')
     ->name('logout');


// =====================
// PELATIHAN
// =====================
Route::prefix('pelatihan')
    ->name('pelatihan.')
    ->group(function () {
        Route::get('/',            [PelatihanController::class, 'program'])->name('index');
        Route::get('/program',     [PelatihanController::class, 'program'])->name('program');
        Route::get('/program/{id}',[PelatihanController::class, 'detailProgram'])->name('detail');
        Route::get('/event',       [PelatihanController::class, 'event'])->name('event');
        Route::get('/event/{id}',  [PelatihanController::class, 'detailEvent'])->name('event.detail');
        Route::get('/pembimbing',  [PelatihanController::class, 'pembimbing'])->name('pembimbing');
        Route::get('/pembimbing/{id}', [PelatihanController::class, 'detailPembimbing'])->name('pembimbing.detail');
        Route::post('/pembimbing/{id}/ulasan', [PelatihanController::class, 'simpanUlasan'])
            ->name('pembimbing.ulasan')
            ->middleware('auth');

    });

// UMKM
Route::prefix('umkm')->group(function () {
  Route::get('/', [UmkmController::class , 'index'])->name('umkm');
  Route::get('/produk', [UmkmController::class , 'produk'])->name('umkm.produk');
  Route::get('/pembimbing', [UmkmController::class , 'pembimbing'])->name('umkm.pembimbing');
  Route::get('/lokasi', [UmkmController::class , 'lokasi'])->name('umkm.lokasi');
});

// Halal Center
Route::prefix('halal-center')->group(function () {
  Route::get('/', [HalalCenterController::class , 'index'])->name('halal-center');
  Route::get('/gratis', [HalalCenterController::class , 'gratis'])->name('halal-center.gratis');
  Route::get('/berbayar', [HalalCenterController::class , 'berbayar'])->name('halal-center.berbayar');
});

// =====================
// HALAL CENTER
// =====================
Route::prefix('halal-center')->group(function () {
  Route::get('/', [HalalCenterController::class , 'index'])->name('halal-center');
  Route::get('/gratis', [HalalCenterController::class , 'gratis'])->name('halal-center.gratis');
  Route::get('/berbayar', [HalalCenterController::class , 'berbayar'])->name('halal-center.berbayar');
});

// =====================
// KONSULTAN
// =====================
Route::prefix('konsultan')->group(function () {
  Route::get('/', [KonsultanController::class , 'index'])->name('konsultan');
  Route::get('/layanan', [KonsultanController::class , 'layanan'])->name('konsultan.layanan');
  Route::get('/paket', [KonsultanController::class , 'paket'])->name('konsultan.paket');
});

// Media
Route::get('/media', [MediaController::class , 'index'])->name('media');


// Member
// Route::get('/members', [MemberController::class , 'index']);

//PRODUK
Route::get('/produk/{id}', [UmkmController::class, 'produkDetail'])->name('produk.show');

// Pembimbing
Route::get('/pembimbing/{id}', [UmkmController::class, 'showMentor'])->name('mentor.show');

//Lokasi
Route::get('/umkm/lokasi', [UmkmController::class, 'lokasi'])->name('umkm.lokasi');
Route::get('/umkm-peta-data', [UmkmController::class, 'apiPeta']);



// ------------------admin --------------------------------
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {

Route::get('/',         [AdminController::class, 'dashboard'])->name('dashboard');
Route::get('/approval/produk',                [AdminController::class, 'approvalProduk'])->name('approval.produk');
     Route::patch('/approval/produk/{id}/approve', [AdminController::class, 'approveProduk'])->name('approval.produk.approve');
     Route::patch('/approval/produk/{id}/reject',  [AdminController::class, 'rejectProduk'])->name('approval.produk.reject');

     Route::get('/approval/program',                [AdminController::class, 'approvalProgram'])->name('approval.program');
     Route::patch('/approval/program/{id}/approve', [AdminController::class, 'approveProgram'])->name('approval.program.approve');
     Route::patch('/approval/program/{id}/reject',  [AdminController::class, 'rejectProgram'])->name('approval.program.reject');

     Route::get('/approval/event',                [AdminController::class, 'approvalEvent'])->name('approval.event');
     Route::patch('/approval/event/{id}/approve', [AdminController::class, 'approveEvent'])->name('approval.event.approve');
     Route::patch('/approval/event/{id}/reject',  [AdminController::class, 'rejectEvent'])->name('approval.event.reject');

     Route::get('/pengguna',                  [AdminController::class, 'pengguna'])->name('pengguna');
     Route::patch('/pengguna/{id}/suspend',   [AdminController::class, 'suspendUser'])->name('pengguna.suspend');
     Route::patch('/pengguna/{id}/unsuspend', [AdminController::class, 'unsuspendUser'])->name('pengguna.unsuspend');

     Route::get('/trainer', [AdminController::class, 'trainer'])->name('trainer');
});
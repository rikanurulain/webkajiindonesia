<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Produk;
use App\Models\Trainer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class AdminController extends Controller
{
    /**
     * Middleware: hanya user dengan role 'admin' yang bisa akses.
     * Middleware 'admin' didaftarkan di bootstrap/app.php (Laravel 11)
     * atau di app/Http/Kernel.php (Laravel 10).
     */
    public function __construct()
    {
        $this->middleware(['auth', 'admin']);
    }

    // =========================================================
    // HELPER: Stats untuk sidebar badge & overview
    // =========================================================
    private function getStats(): array
    {
        // Hitung produk pending (kolom status di tabel produks, default 'pending')
        $pendingProduk   = Produk::where('status', 'pending')->count();

        // Program & Event: karena belum ada tabel terpisah,
        // Trainer = pembimbing/trainer. Jika Anda punya tabel program/event,
        // ganti query di bawah ini sesuai model yang sesuai.
        $pendingProgram  = 0; // Trainer::where('status', 'pending')->count();
        $pendingEvent    = 0; // Event::where('status', 'pending')->count();
        $totalPending    = $pendingProduk + $pendingProgram + $pendingEvent;

        $pendingHariIni  = Produk::where('status', 'pending')
                                 ->whereDate('created_at', today())
                                 ->count();

        $disetujuiBulan  = Produk::where('status', 'approved')
                                 ->whereMonth('updated_at', now()->month)
                                 ->whereYear('updated_at', now()->year)
                                 ->count();

        $totalUsers      = User::count();
        $totalUmkm       = User::where(function ($q) {
                               $q->where('is_umkm', true)->orWhere('role', 'umkm');
                           })->count();
        $totalPembimbing = User::where(function ($q) {
                               $q->where('is_pembimbing', true)->orWhere('role', 'pembimbing');
                           })->count();

        return compact(
            'pendingProduk', 'pendingProgram', 'pendingEvent',
            'totalPending', 'pendingHariIni', 'disetujuiBulan',
            'totalUsers', 'totalUmkm', 'totalPembimbing'
        );
    }

    // =========================================================
    // DASHBOARD OVERVIEW
    // =========================================================
    public function dashboard()
    {
        $s = $this->getStats();

        // Antrian terbaru: ambil 5 produk pending terbaru sebagai contoh
        $produkPending = Produk::where('status', 'pending')
                               ->latest()
                               ->take(5)
                               ->get();

        $antrian_terbaru = $produkPending->map(function ($p) {
            return [
                'id'            => $p->id,
                'type'          => 'produk',
                'nama'          => $p->nama,
                'foto'          => $p->foto,
                'submitter'     => $p->whatsapp ?? 'UMKM',
                'submitter_role'=> 'UMKM',
                'avatar_color'  => 'var(--accent3)',
                'tanggal'       => $p->created_at,
            ];
        })->toArray();

        $pengguna_terbaru = User::latest()->take(5)->get();
        $produk_terbaru   = Produk::latest()->take(5)->get();

        // Pass stats ke view (juga dipakai sidebar)
        $stats = [
            'total_pending'    => $s['totalPending'],
            'pending_hari_ini' => $s['pendingHariIni'],
            'pending_produk'   => $s['pendingProduk'],
            'pending_program'  => $s['pendingProgram'],
            'pending_event'    => $s['pendingEvent'],
            'disetujui_bulan'  => $s['disetujuiBulan'],
            'total_users'      => $s['totalUsers'],
            'total_umkm'       => $s['totalUmkm'],
            'total_pembimbing' => $s['totalPembimbing'],
        ];

        return view('admin.dashboard', compact(
            'stats', 'antrian_terbaru', 'pengguna_terbaru', 'produk_terbaru'
        ));
    }

    // =========================================================
    // APPROVAL PRODUK
    // =========================================================
    public function approvalProduk(Request $request)
    {
        $status  = $request->query('status', 'pending');
        $allowed = ['pending', 'approved', 'rejected'];
        if (!in_array($status, $allowed)) $status = 'pending';

        $produks = Produk::where('status', $status)
                         ->latest()
                         ->paginate(15);

        $counts = [
            'pending'  => Produk::where('status', 'pending')->count(),
            'approved' => Produk::where('status', 'approved')->count(),
            'rejected' => Produk::where('status', 'rejected')->count(),
        ];

        $stats = $this->getSidebarStats();

        return view('admin.approval-produk', compact('produks', 'status', 'counts', 'stats'));
    }

    public function approveProduk(Request $request, $id)
    {
        $produk = Produk::findOrFail($id);
        $produk->update(['status' => 'approved', 'catatan_admin' => $request->catatan]);

        return redirect()->back()->with('success', "Produk \"{$produk->nama}\" berhasil disetujui.");
    }

    public function rejectProduk(Request $request, $id)
    {
        $request->validate(['catatan' => 'nullable|string|max:500']);

        $produk = Produk::findOrFail($id);
        $produk->update(['status' => 'rejected', 'catatan_admin' => $request->catatan]);

        return redirect()->back()->with('success', "Produk \"{$produk->nama}\" telah ditolak.");
    }

    // =========================================================
    // APPROVAL PROGRAM
    // (Sesuaikan dengan model Program Anda jika sudah ada)
    // =========================================================
    public function approvalProgram(Request $request)
    {
        $status = $request->query('status', 'pending');

        // Placeholder: gunakan Trainer sebagai contoh
        // Ganti dengan model Program yang sesungguhnya
        $programs = Trainer::where('status', $status ?? 'pending')
                           ->latest()
                           ->paginate(15);

        $counts = [
            'pending'  => Trainer::where('status', 'pending')->count(),
            'approved' => Trainer::where('status', 'approved')->count(),
            'rejected' => Trainer::where('status', 'rejected')->count(),
        ];

        $stats = $this->getSidebarStats();

        return view('admin.approval-program', compact('programs', 'status', 'counts', 'stats'));
    }

    public function approveProgram(Request $request, $id)
    {
        $program = Trainer::findOrFail($id);
        $program->update(['status' => 'approved']);

        return redirect()->back()->with('success', 'Program berhasil disetujui.');
    }

    public function rejectProgram(Request $request, $id)
    {
        $program = Trainer::findOrFail($id);
        $program->update(['status' => 'rejected', 'catatan_admin' => $request->catatan]);

        return redirect()->back()->with('success', 'Program telah ditolak.');
    }

    // =========================================================
    // APPROVAL EVENT
    // (Sesuaikan dengan model Event Anda)
    // =========================================================
    public function approvalEvent(Request $request)
    {
        $status = $request->query('status', 'pending');

        // Placeholder: ganti dengan model Event sesungguhnya
        $events = Trainer::where('status', $status ?? 'pending')
                         ->latest()
                         ->paginate(15);

        $counts = [
            'pending'  => 0,
            'approved' => 0,
            'rejected' => 0,
        ];

        $stats = $this->getSidebarStats();

        return view('admin.approval-event', compact('events', 'status', 'counts', 'stats'));
    }

    public function approveEvent(Request $request, $id)
    {
        // Ganti dengan model Event
        return redirect()->back()->with('success', 'Event berhasil disetujui.');
    }

    public function rejectEvent(Request $request, $id)
    {
        return redirect()->back()->with('success', 'Event telah ditolak.');
    }

    // =========================================================
    // MANAJEMEN PENGGUNA
    // =========================================================
    public function pengguna(Request $request)
    {
        $query = User::query();

        if ($request->has('role') && $request->role) {
            $role = $request->role;
            if ($role === 'umkm') {
                $query->where(fn($q) => $q->where('is_umkm', true)->orWhere('role', 'umkm'));
            } elseif ($role === 'pembimbing') {
                $query->where(fn($q) => $q->where('is_pembimbing', true)->orWhere('role', 'pembimbing'));
            } else {
                $query->where('role', $role);
            }
        }

        $users = $query->latest()->paginate(20);
        $stats = $this->getSidebarStats();

        return view('admin.pengguna', compact('users', 'stats'));
    }

    public function suspendUser($id)
    {
        $user = User::findOrFail($id);
        if ($user->role === 'admin') {
            return redirect()->back()->with('error', 'Tidak bisa suspend admin.');
        }
        $user->update(['suspended_at' => now()]);
        return redirect()->back()->with('success', "Pengguna \"{$user->name}\" berhasil di-suspend.");
    }

    public function unsuspendUser($id)
    {
        $user = User::findOrFail($id);
        $user->update(['suspended_at' => null]);
        return redirect()->back()->with('success', "Pengguna \"{$user->name}\" berhasil diaktifkan kembali.");
    }

    // =========================================================
    // MANAJEMEN TRAINER
    // =========================================================
    public function trainer(Request $request)
    {
        $trainers = Trainer::latest()->paginate(20);
        $stats    = $this->getSidebarStats();

        return view('admin.trainer', compact('trainers', 'stats'));
    }

    // =========================================================
    // HELPER: Stats ringkas untuk sidebar badge
    // =========================================================
    private function getSidebarStats(): array
    {
        return [
            'total_pending'    => Produk::where('status', 'pending')->count(),
            'pending_produk'   => Produk::where('status', 'pending')->count(),
            'pending_program'  => 0,
            'pending_event'    => 0,
            'total_users'      => User::count(),
        ];
    }
}
<?php

namespace App\Http\Controllers;

use Illuminate\View\View;
use App\Models\Member;
use App\Models\Team;
use App\Models\Produk;
use App\Models\Mentor;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\log;

class UmkmController extends Controller
{
    public function index(): View
    {

    $members = Member::all();
    $teams = Team::all();
    
        return view('pages.umkm', [
            'title' => 'UMKM',
            'metaDescription' => 'Pendampingan dan penguatan kapasitas UMKM oleh Kaji Indonesia.',
            'members' => $members,
            'teams' => $teams,
        ]);
    }
    
    public function produk(): View
    {
        $produks = Produk::all();

        return view('pages.umkm-produk', [
            'title' => 'Produk UMKM',
            'produks' => $produks,
            ]);
    }

    public function produkDetail($id): View
        {
            $produk  = Produk::findOrFail($id);
            $lainnya = Produk::where('id', '!=', $id)->take(20)->get();

            return view('pages.detail-produk', [
                'title'       => $produk->nama,
                'metaDescription' => $produk->deskripsi,
                'produk'      => $produk,
                'lainnya'     => $lainnya,
            ]);
        }

    public function pembimbing(): View
    {
        return view('pages.umkm-pembimbing', [
            'title' => 'Pembimbing UMKM',
            'metaDescription' => 'Tim pembimbing UMKM yang berpengalaman di Kaji Indonesia.',
            'mentor' => Mentor::all(),
        ]);
    }

    public function showMentor($id)
    {
        $m = Mentor::findOrFail($id);
        return view('pages.detail-pembimbing', compact('m'));
    }

    public function lokasi(): View
    {
        return view('pages.umkm-lokasi', [
            'title' => 'Lokasi UMKM',
            'metaDescription' => 'Lokasi UMKM yang didampingi oleh Kaji Indonesia.',
        ]);
    }


  // ─────────────────────────────────────────────────────────
    // API endpoint — kembalikan data UMKM sebagai JSON
    // GET /api/umkm-peta
    // ─────────────────────────────────────────────────────────

    public function apiPeta()
    {
        // Geocode data yang belum punyakoordinat
        $this->geocodeBelumAda();

        // Ambil semua data UMKM dengan koordinat
        $produks = Produk::whereNotNull('lat')
            ->whereNotNull('lng')
            ->select(['id', 'nama', 'foto','alamat', 'lat', 'lng'])
            ->get();

        $data = [];
        foreach ($produks as $p) {
            $data[] = [
                'id' => $p->id,
                'nama' => $p->nama,
                'alamat' => $p->alamat,
                'foto' => $p->foto ? asset('storage/produk-pict/' . $p->foto) : null,
                'lat' => $p->lat,
                'lng' => $p->lng,
            ];
        }

        return response()->json([
            'status' => 'success',
            'total' => count($data),
            'data' => $data,
            ]);
    }

     // ─────────────────────────────────────────────────────────
    // Geocoding via Nominatim (OpenStreetMap) — gratis
    // ─────────────────────────────────────────────────────────

    private function geocodeBelumAda(): void
    {
       $belum = Produk::whereNull('lat')
       ->WhereNull('lng')
       ->whereNotNull('alamat')
       ->where('alamat', '!=', '')
       ->get();

       foreach ($belum as $produk) {
        $koordinat = $this->geocodeAlamat($produk->alamat);

        if ($koordinat) {
            $produk->update([
                'lat' => $koordinat['lat'],
                'lng' => $koordinat['lng'],
            ]);
        }
        
        //nominatim wajib jeda 1 detik antar request
        sleep(1);
       }
    }

    private function geocodeAlamat(string $alamat): ?array
    {
        $cacheKey = 'geocode_osm_' . md5($alamat);
 
        return Cache::remember($cacheKey, now()->addDays(30), function () use ($alamat) {
            try {
                $response = Http::timeout(8)
                    ->withHeaders([
                        'User-Agent'      => 'KaryaKamiUMKMApp/1.0 (kontak@emailkamu.com)',
                        'Accept-Language' => 'id,en',
                    ])
                    ->get('https://nominatim.openstreetmap.org/search', [
                        'q'            => $alamat . ', Indonesia',
                        'format'       => 'json',
                        'limit'        => 1,
                        'countrycodes' => 'id',
                    ]);
 
                $hasil = $response->json();
 
                if (!empty($hasil)) {
                    return [
                        'lat' => (float) $hasil[0]['lat'],
                        'lng' => (float) $hasil[0]['lon'],
                    ];
                }
 
                Log::warning("Geocode tidak ditemukan: {$alamat}");
                return null;
 
            } catch (\Exception $e) {
                Log::error("Geocode error: " . $e->getMessage());
                return null;
            }
        });
    
    }
}